import streamlit as st
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from Levenshtein import distance as lev_distance
from sentence_transformers import SentenceTransformer
import numpy as np
import nltk
import string

# For Ham Classification

f = 'sms_data.csv'
columns = ['label', 'message']
data = pd.read_csv(f, sep='\t', names=columns)
data = data.drop_duplicates(subset='message')

label_to_int = {'ham':0,'spam':1}
int_to_label = {0:'ham',1:'spam'}

data['label'] = data.label.map(label_to_int)

nltk.download('stopwords')
nltk.download('punkt')

from nltk.corpus import stopwords
english_stopwords = set(stopwords.words('english'))

def PreprocessMessages(text):
  text = text.lower()
  text = text.translate(str.maketrans('', '', string.punctuation))
  tokenized_text = nltk.word_tokenize(text)
  clean_text = [word for word in tokenized_text if word not in english_stopwords]
  return clean_text

data['message'] = data['message'].apply(lambda x: PreprocessMessages(x))

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(data['message'],data['label'], random_state = 42)

vectorizer = CountVectorizer(analyzer=lambda x: x)  

X_train_counts = vectorizer.fit_transform(X_train)
classifier = MultinomialNB()
classifier.fit(X_train_counts, y_train)

# For Sentence Similarity

model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')

def cosine_similarity(v1,v2):
    "return the cosine similarity between two vectors"

    # calculate the dot product of v1 & v2
    dot_product = np.dot(v1,v2)

    #calculate the norms of v1 & v2
    norm_1 = np.linalg.norm(v1)
    norm_2 = np.linalg.norm(v2)

    # return the cosine similarity
    return dot_product / (norm_1 * norm_2)

# Streamlit website:

st.sidebar.title('Navigation')
selection = st.sidebar.radio('Go to', ['Home', 'Word Similarity', 'Spam Detection','Sentence Similarity'])

if selection == 'Home':
   st.title('Natural Language Processing Application')
   st.write('Welcome to the Natural Language Processing application. Go to the sidebar to select an option.')
   st.markdown("""
    **Course Reference:**
    LING 360 - Boğaziçi University Department of Linguistics Spring 2024, Streamlit Demo Lab\n\n
    **Course Instructor:** Dr. Ümit Atlamaz\n
    **Course TAs:** Onur Keleş & Berat Doğan \n\n 
    """
   )
   col1, col2, col3, col4 = st.columns(4)
   col1.image("p1.jpg", caption="Funny meme haha")
   col2.image("p2.jpg", caption="NLP is great")
   col3.image("p3.jpg", caption="Go Computational Linguistics!")
   col4.image("p4.jpg", caption="Streamlit is awesome!")

elif selection == 'Word Similarity':
   st.title('Word Similarity')
   word1 = st.text_input('Enter the first word:')
   word2 = st.text_input('Enter the second word:')
   if st.button('Calculate Similarity'):
         similarity = lev_distance(word1, word2)
         st.write(f'The Levenshtein distance between {word1} and {word2} is {similarity}')

elif selection == 'Spam Detection':
    st.title('Spam Detection')
    text_input = st.text_area('Enter the message:')
    if st.button('Classify'):
        sample_message = [PreprocessMessages(text_input)]
        sample_message_processed = vectorizer.transform(sample_message)
        st.write(int_to_label[int(classifier.predict(sample_message_processed))])
        prediction_prob = classifier.predict_proba(sample_message_processed)
        st.write(f"Spam Probability: {prediction_prob[0][1]}")
        st.write(f"Ham Probability: {prediction_prob[0][0]}")

elif selection == 'Sentence Similarity':
    st.title('Sentence Similarity')
    st.write('Enter two sentences to calculate their cosine similarity')
    sentence1 = st.text_input('Enter the first sentence:')
    sentence2 = st.text_input('Enter the second sentence:')
    if st.button('Calculate Similarity'):
        sentence1_embedding = model.encode(sentence1)
        sentence2_embedding = model.encode(sentence2)
        similarity = cosine_similarity(sentence1_embedding, sentence2_embedding)
        st.write(f'The cosine similarity between the two sentences is {similarity}')
